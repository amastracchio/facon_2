package SNMP::Util_env;
use strict;

## Set up environment variables.
$ENV{'MIBDIRS'} = '/usr/local/lib/share/snmp/mibs';


# example $ENV{'MIBFILES'} = '/mibdir/rfc-1407.mib:/mibdir/rfc-1406.mib';
#$ENV{'MIBFILES'} = ''; 
